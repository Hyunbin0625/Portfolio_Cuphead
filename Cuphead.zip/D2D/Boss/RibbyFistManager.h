#pragma once

class RibbyFistManager
{
public:
	RibbyFistManager();

public:
	void Init(UINT totalBullet, float bulletSpeed, Vector2 position, float rotation, int currentPhase);

	void Update();
	void Render();

public:
	shared_ptr<RibbyFist> GetBullet(int index) { return bullets[index]; }
	vector<shared_ptr<RibbyFist>> GetBullets() { return bullets; }

	int GetCurrentIndex() { return currentIndex; }
	bool GetEnd() { return bEnd; }

	void SetCurrentIndex(int currentIndex) { this->currentIndex = currentIndex; }
	void SetPosition(Vector2 position) { this->position = position; }
	void SetRotation(float rotation) { this->rotation = rotation; }
	void SetTotalSize(float totalSize) { this->totalSize = totalSize; }
	void SetBulletSpeed(float bulletSpeed) { this->bulletSpeed = bulletSpeed; }

private:
	vector<shared_ptr<RibbyFist>> bullets;
	vector<shared_ptr<RibbyClapBall>> balls;
	mt19937 mt;

	UINT totalBullet = 0;
	float bulletSpeed = 0;

	// Index
	int currentIndex = 0;
	int parrySlapIndex = 0;

	Vector2 position;
	float rotation = 0.0f;

	float totalSize = 1.0f;

	float time = 0.0f;
	float rebound = 90.0f * totalSize;
	int count = 0;
	bool bUp = true;

	int currentPhase = 1;
	bool bEnd = true;
};