#include "stdafx.h"
#include "Tuto_Cube.h"

Tuto_Cube::Tuto_Cube(const Vector2& position, const Vector2& scale, float rotation)
	: position(position), scale(scale), rotation(rotation)
{
	textureRect = make_unique<TextureRect>(position, scale, rotation, L"_Textures/Scene_Tutorial/tutorial_cube.png");
	collision = make_shared<ColorRect>(position + colPos, scale + colScale, 0.0f, BLACK);

	OB = make_unique<OutlineBuffer>();

	collision->AddComponent(make_shared<ColliderComponent>(ColliderType::RECT));
}

void Tuto_Cube::Update()
{
	if (collision->GET_COMP(Collider)->Intersect(INPUT->GetMousePosition()) && INPUT->Press(VK_LBUTTON))
	{
		position = INPUT->GetMousePosition();
		textureRect->SetPosition(position);
		collision->SetPosition(position + colPos);
	}

	textureRect->SetScale(scale * size);
	collision->SetScale((scale + colScale) *size);
	textureRect->SetRotation(rotation * 57.2);
	collision->SetRotation(rotation * 57.2);

	textureRect->Update();
	collision->Update();
}

void Tuto_Cube::Render()
{
	OB->SetPSBuffer(2);

	textureRect->Render();
//	collision->Render();
}

void Tuto_Cube::GUI(int ordinal)
{
	string objName = textureRect->GetName() + to_string(ordinal);

//	if (ImGui::BeginMenu(objName.c_str()))
//	{
//		ImGui::Text(objName.c_str());
//		
//		ImGui::SliderFloat("Size", &size, 0.1f, 5.0f, "%.2f");
//		ImGui::SliderAngle("Rotation", &rotation);
//
//		if(ImGui::Button("Delete", ImVec2(50, 30)))
//
//		ImGui::EndMenu();
//	}

	if (ImGui::BeginMenu(objName.c_str()))
	{
		OB->SetOutline(true);

		ImGui::Text(objName.c_str());

		ImGui::SliderFloat("Size", &size, 0.1f, 5.0f, "%.2f");
		ImGui::SliderAngle("Rotation", &rotation);

	//	if (ImGui::Button("Delete", ImVec2(50, 30)))

		ImGui::EndMenu();
	}
	else
	{
		OB->SetOutline(false);
	}
}
