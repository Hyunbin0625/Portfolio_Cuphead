#pragma once

class Tuto_Cube : public ITutoObjects
{
public:
	Tuto_Cube(const Vector2& position, const Vector2& scale, float rotation);

public:
	virtual void Update() override;
	virtual void Render() override;
	virtual void GUI(int ordinal) override;

private:
	unique_ptr<TextureRect> textureRect;
	shared_ptr<ColorRect> collision;

	unique_ptr<OutlineBuffer> OB;

	Vector2 position;
	Vector2 scale;
	float rotation;

	Vector2 colPos = Vector2(-10, -4);
	Vector2 colScale = Vector2(-33, -54);
	
	float size = 1;

	bool bDelete = 0;
};
