#pragma once

class ITutoObjects
{
public:
	ITutoObjects() = default;
	virtual ~ITutoObjects() = default;

public:
	virtual void Update() = 0;
	virtual void Render() = 0;
	virtual void GUI(int ordinal) = 0;
};
